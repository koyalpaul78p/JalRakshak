const tips = [
  ["🚿","Shorten your shower","Keep showers brief. A bucket bath can also help you monitor how much water you use.","नहाने का समय कम रखें। बाल्टी से नहाने पर पानी की मात्रा पर नज़र रखना आसान होता है।"],
  ["🚰","Turn off the tap","Close the tap while brushing your teeth or soaping your hands.","दाँत साफ़ करते और हाथों में साबुन लगाते समय नल बंद रखें।"],
  ["🧺","Wash full loads","Run washing machines only when you have a suitable full load.","वॉशिंग मशीन तभी चलाएँ जब कपड़ों का पूरा और उचित लोड हो।"],
  ["🪴","Water plants wisely","Water plants early in the morning or evening to reduce evaporation.","पानी के वाष्पीकरण को कम करने के लिए सुबह या शाम पौधों को पानी दें।"],
  ["🔧","Fix leaking taps","Tell an adult or maintenance person when you notice a leak and get it repaired.","नल से रिसाव दिखे तो घर के बड़े व्यक्ति या रखरखाव कर्मी को बताएँ।"],
  ["🧽","Use a bucket to clean","Use a bucket instead of a continuously running hose for cleaning.","सफाई के लिए लगातार चलती पाइप की जगह बाल्टी का उपयोग करें।"]
];
const quiz = [
  {q:"Which action saves water while brushing?",o:["Keep the tap running","Turn off the tap","Use more water"],a:1,e:"Turning off the tap avoids unnecessary water flow."},
  {q:"What is rainwater harvesting?",o:["Collecting and storing rainwater","Making artificial rain","Washing roads"],a:0,e:"Rainwater harvesting collects rain for later suitable use."},
  {q:"When is a good time to water garden plants?",o:["Hot midday","Early morning or evening","During strong sunlight"],a:1,e:"Less water is lost through evaporation in cooler hours."},
  {q:"What should you do if a tap is leaking?",o:["Ignore it","Open it more","Report it and arrange repair"],a:2,e:"Repairing leaks prevents avoidable water waste."},
  {q:"Is untreated rainwater always safe to drink?",o:["Yes, always","No, it needs proper treatment","Only in summer"],a:1,e:"Rainwater needs appropriate treatment before drinking."}
];
const goals = ["Turn off the tap while brushing","Use only the water I need","Check for leaking taps","Reuse suitable leftover water for plants","Remind someone about one water-saving habit"];
const $ = id => document.getElementById(id);
let lang = localStorage.getItem("jal_lang") || "en";
let qIndex=0, score=0, answered=false;
const todayKey = new Date().toISOString().slice(0,10);
function getState(){try{return JSON.parse(localStorage.getItem("jal_state")||"{}")}catch{return {}}}
function saveState(s){localStorage.setItem("jal_state",JSON.stringify(s))}
function applyLanguage(){
  document.documentElement.lang=lang;
  document.querySelectorAll("[data-en]").forEach(el=>{el.textContent=el.dataset[lang]});
  $("languageBtn").textContent=lang==="en"?"हिंदी":"English";
  renderTips(); renderQuiz();
}
$("languageBtn").addEventListener("click",()=>{lang=lang==="en"?"hi":"en";localStorage.setItem("jal_lang",lang);applyLanguage()});
function renderTips(){
  $("tipsList").innerHTML=tips.map((t,i)=>`<article class="tip-card"><span class="tip-emoji">${t[0]}</span><div><h3>${lang==="en"?t[1]:t[3]}</h3><p>${lang==="en"?t[2]:t[4]}</p><button type="button" data-tip="${i}">${lang==="en"?"Mark explored":"देख लिया"}</button></div></article>`).join("");
  $("tipsList").querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{const s=getState();s.tips=s.tips||[];const n=Number(b.dataset.tip);if(!s.tips.includes(n))s.tips.push(n);saveState(s);updateStats();b.textContent=lang==="en"?"Explored ✓":"देख लिया ✓"}));
}
function renderGoals(){
  const s=getState(); if(s.goalDate!==todayKey){s.goalDate=todayKey;s.done=[];saveState(s)}
  $("goalList").innerHTML=goals.map((g,i)=>`<label class="goal-item"><input type="checkbox" data-goal="${i}" ${s.done?.includes(i)?"checked":""}><span>${lang==="en"?g:["दाँत साफ़ करते समय नल बंद रखें","ज़रूरत भर पानी उपयोग करें","टपकते नल की जाँच करें","पौधों के लिए बचा हुआ साफ़ पानी दोबारा उपयोग करें","किसी को पानी बचाने की एक आदत याद दिलाएँ"][i]}</span></label>`).join("");
  $("goalList").querySelectorAll("input").forEach(cb=>cb.addEventListener("change",()=>{const st=getState();st.done=st.done||[];const n=Number(cb.dataset.goal);st.done=cb.checked?[...new Set([...st.done,n])]:st.done.filter(x=>x!==n);saveState(st);updateStats()}));
}
function updateStats(){const s=getState();$("goalCount").textContent=(s.done||[]).length;$("tipCount").textContent=(s.tips||[]).length;$("quizBest").textContent=s.best||0;$("impactNumber").textContent=(s.done||[]).length}
$("resetGoals").addEventListener("click",()=>{const s=getState();s.done=[];s.goalDate=todayKey;saveState(s);renderGoals();updateStats()});
$("calculateBtn").addEventListener("click",()=>{
  const shower=Math.max(0,Number($("showers").value)||0), flush=Math.max(0,Number($("toilet").value)||0), laundry=Math.max(0,Number($("laundry").value)||0), dishes=Math.max(0,Number($("dishes").value)||0);
  // Approximate illustrative values, not measured household data.
  const total=shower*35+flush*6+laundry*50/7+dishes*15;
  $("calcResult").innerHTML=`<strong>${Math.round(total)} litres/day</strong><br>${lang==="en"?"Approximate daily household use for the activities entered.":"दिए गए कामों के लिए घर के रोज़ाना उपयोग का अनुमान।"}`;
});
function renderQuiz(){
  if(qIndex>=quiz.length){$("questionNumber").textContent=lang==="en"?"Quiz completed":"क्विज़ पूरा हुआ";$("questionText").textContent=lang==="en"?`You scored ${score} out of ${quiz.length}!`:`आपका स्कोर ${quiz.length} में से ${score} है!`;$("answerOptions").innerHTML="";$("quizFeedback").textContent=lang==="en"?"Great effort! Keep learning and saving water.":"बहुत अच्छा! सीखते रहें और पानी बचाते रहें।";$("nextQuestion").hidden=true;$("restartQuiz").hidden=false;const s=getState();s.best=Math.max(s.best||0,score);saveState(s);updateStats();return}
  const item=quiz[qIndex];$("questionNumber").textContent=lang==="en"?`Question ${qIndex+1} of ${quiz.length}`:`प्रश्न ${qIndex+1} / ${quiz.length}`;$("scoreLabel").textContent=(lang==="en"?"Score: ":"स्कोर: ")+score;$("quizProgress").style.width=((qIndex+1)/quiz.length*100)+"%";$("questionText").textContent=item.q;$("answerOptions").innerHTML=item.o.map((o,i)=>`<button type="button" data-answer="${i}">${lang==="en"?o:[["नल खुला छोड़ें","नल बंद रखें","ज़्यादा पानी उपयोग करें"],["बारिश का पानी इकट्ठा करके रखना","कृत्रिम बारिश करना","सड़क धोना"],["दोपहर की तेज़ धूप में","सुबह जल्दी या शाम को","तेज़ धूप के समय"],["अनदेखा करें","नल और खोल दें","रिसाव की सूचना देकर मरम्मत कराएँ"],["हाँ, हमेशा","नहीं, पीने से पहले उचित शुद्धिकरण चाहिए","केवल गर्मियों में"]][qIndex][i]}</button>`).join("");$("quizFeedback").textContent="";$("nextQuestion").hidden=true;$("restartQuiz").hidden=true;answered=false;
  $("answerOptions").querySelectorAll("button").forEach(btn=>btn.addEventListener("click",()=>{if(answered)return;answered=true;const chosen=Number(btn.dataset.answer);if(chosen===item.a)score++;$("answerOptions").querySelectorAll("button").forEach((b,i)=>{b.disabled=true;if(i===item.a)b.classList.add("correct");else if(i===chosen)b.classList.add("wrong")});$("scoreLabel").textContent=(lang==="en"?"Score: ":"स्कोर: ")+score;$("quizFeedback").textContent=(chosen===item.a?(lang==="en"?"Correct! ":"सही जवाब! "):(lang==="en"?"Not quite. ":"सही नहीं। "))+ (lang==="en"?item.e:["नल बंद रखने से अनावश्यक पानी बहने से बचता है।","वर्षा जल संचयन से बारिश का पानी बाद में उपयोग के लिए इकट्ठा किया जाता है।","ठंडे समय में वाष्पीकरण कम होता है।","रिसाव ठीक करने से पानी की बर्बादी रुकती है।","पीने से पहले बारिश के पानी का उचित शुद्धिकरण ज़रूरी है।"][qIndex]);$("nextQuestion").hidden=false;}));
}
$("nextQuestion").addEventListener("click",()=>{qIndex++;renderQuiz()});
$("restartQuiz").addEventListener("click",()=>{qIndex=0;score=0;renderQuiz()});
function navigate(){const id=location.hash.slice(1)||"home";document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===id));document.querySelectorAll(".nav-link").forEach(a=>a.classList.toggle("active",a.getAttribute("href")==="#"+id));window.scrollTo(0,0);if(id==="impact")renderGoals()}
window.addEventListener("hashchange",navigate);
applyLanguage();renderGoals();updateStats();navigate();

if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) { window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {})); }
