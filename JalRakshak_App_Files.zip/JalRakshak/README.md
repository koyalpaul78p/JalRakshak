# JalRakshak – Every Drop Matters

A free, mobile-friendly water conservation awareness app built with HTML, CSS and JavaScript.

## Features
- Home dashboard
- Water-saving tips
- Rainwater harvesting guide
- Illustrative water-use calculator
- Five-question quiz
- Daily water-saving checklist
- English/Hindi toggle
- Local progress storage
- Installable PWA with basic offline caching

## Run locally
Open `index.html` in a browser. For PWA installation and offline caching, serve the folder over HTTPS or localhost.

## Publish free with GitHub Pages
1. Create a public GitHub repository named `JalRakshak`.
2. Upload all files in this folder to the repository root (not the ZIP itself).
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for the published URL shown in the Pages section.

## Install on Android
1. Open the published HTTPS website in Chrome.
2. Open the three-dot menu.
3. Choose **Install app** or **Add to Home screen** (wording may vary).
4. Follow the prompt.

## Notes
- No paid API or database is used.
- Progress is saved in the browser's local storage on that device.
- Calculator values are illustrative estimates, not measured consumption.
- Rainwater should be treated appropriately before drinking.
- This project is a web app/PWA, not a signed Play Store APK.
